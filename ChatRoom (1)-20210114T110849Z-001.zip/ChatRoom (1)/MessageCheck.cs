﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatRoom
{
    class MessageCheck
    {
        public delegate void DelAddNameHandler(string message);
        public DelAddNameHandler Addusername;


        private  UdpChat udpchat;
        private ChatRoom chatRoom = new ChatRoom();
        public string otherUser = "";

        //public TextBox _textBox;
        //public TextBox name_textBox;
        //public Button _button;

        public MessageCheck(UdpChat udpChat)
        {
            udpchat = udpChat;
        }
        public void MessageJudgment(string message)
        {

            if (message.StartsWith("Online"))
            {
                if (message.Substring(6) == ChatRoom.username)
                {
                    udpchat.SendMessage("ISREPEAT");

                }
                else
                {
                    //AdddUserNAME(message.Substring(6));
                    //chatRoom.AdddUserNAME(message.Substring(6));
                    //Addusername.Invoke(message.Substring(6));
                    //chatRoom.addname(message.Substring(6));
                    otherUser = message.Substring(6);
                    udpchat.SendMessage("Respones" + ChatRoom.username);
                }
            }
            else if (message.StartsWith("Offline"))
            {
                //CancelUserName();
                chatRoom.CancelUserName();
            }
            else if (message.StartsWith("Respones"))
            {
                //AdddUserNAME(message.Substring(8));
                chatRoom.AdddUserNAME(message.Substring(8));
            }
            else if (message.StartsWith("ISREPEAT"))
            {
                Login lg = new Login();
                //ChatRoom chatRoom = new ChatRoom();

                //RepeatUserName();
                chatRoom.RepeatUserName();
                MessageBox.Show("Repeat Name!!");

                lg.Owner = chatRoom;

                if (lg.ShowDialog(chatRoom) == DialogResult.OK)
                {
                    ChatRoom.username = lg.GetName();

                    //name_textBox.Text = ChatRoom.username;
                    chatRoom.SetText(ChatRoom.username);
                    udpchat.SendMessage("Online" + ChatRoom.username);
                }
                else
                {
                    //_button.Enabled = true;
                }
            }
            else
            {
                chatRoom.AddTextHistory(message);
            }

        }

        private void ChatRoom_E_AdddUserNAME1(string username)
        {
            throw new NotImplementedException();
        }

        private void ChatRoom_E_AdddUserNAME(string username)
        {
            throw new NotImplementedException();
        }



        //public delegate void DelAddTextHistory(string sMessage);
        //public void AddTextHistory(string sMessage)
        //{
        //    if (_textBox.InvokeRequired)
        //    {
        //        DelAddTextHistory del = new DelAddTextHistory(AddTextHistory);
        //        _textBox.Invoke(del, sMessage);
        //    }
        //    else
        //    {
        //        _textBox.AppendText(sMessage + "\r\n");
        //    }
        //}
        //public delegate void DelAddUserName(string username);
        //public void AdddUserNAME(string username)
        //{
        //    if (name_textBox.InvokeRequired)
        //    {
        //        DelAddUserName del = new DelAddUserName(AdddUserNAME);
        //        name_textBox.Invoke(del, username);
        //    }
        //    else
        //    {
        //        name_textBox.AppendText("\r\n" + username);
        //    }
        //}
        //public delegate void DelCancelUserName();
        //public void CancelUserName()
        //{
        //    if (name_textBox.InvokeRequired)
        //    {
        //        DelCancelUserName del = new DelCancelUserName(CancelUserName);
        //        name_textBox.Invoke(del);
        //    }
        //    else
        //    {
        //        name_textBox.Clear();
        //        name_textBox.Text = ChatRoom.username;
        //    }
        //}
        //public delegate void DelRepeatUserName();
        //public void RepeatUserName()
        //{
        //    if (name_textBox.InvokeRequired)
        //    {
        //        DelRepeatUserName del = new DelRepeatUserName(RepeatUserName);
        //        name_textBox.Invoke(del);
        //    }
        //    else
        //    {
        //        name_textBox.Text = "";

        //    }
        //}




    }
}

